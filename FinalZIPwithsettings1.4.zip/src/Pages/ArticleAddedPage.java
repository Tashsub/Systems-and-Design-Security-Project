package Pages;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;

public class ArticleAddedPage extends JFrame {

	private JPanel contentPane;
	private int i;
	public static JTextField txtCounter;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ArticleAddedPage frame = new ArticleAddedPage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ArticleAddedPage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(600, 20, 800, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		JLabel labelTitle = new JLabel("Your Article has been submitted!");
		labelTitle.setFont(new Font("Tahoma", Font.PLAIN, 23));
		labelTitle.setBounds(228, 13, 343, 42);
		contentPane.add(labelTitle);
		
		JLabel labelQuestion = new JLabel("Do you want to add a board of authors for the Article that you just submitted?");
		labelQuestion.setFont(new Font("Tahoma", Font.PLAIN, 19));
		labelQuestion.setBounds(58, 68, 664, 49);
		contentPane.add(labelQuestion);
		
		JLabel labeltext = new JLabel("Board Authors added until now");
		labeltext.setForeground(Color.GRAY);
		labeltext.setFont(new Font("Tahoma", Font.PLAIN, 19));
		labeltext.setBounds(326, 139, 333, 40);
		contentPane.add(labeltext);
		
		//btnadd
		JButton btnBoardA = new JButton("ADD");
		btnBoardA.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AddAuthorPage a = new AddAuthorPage();
				a.setVisible(true);
			}
		});
		btnBoardA.setFont(new Font("Tahoma", Font.PLAIN, 21));
		btnBoardA.setBounds(202, 138, 85, 42);
		contentPane.add(btnBoardA);
		
		//btnDone
		JButton btnDone = new JButton("DONE");
		btnDone.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				LogInPage l = new LogInPage();
				l.setVisible(true);
			}
		});
		btnDone.setFont(new Font("Tahoma", Font.PLAIN, 21));
		btnDone.setBounds(312, 198, 143, 42);
		contentPane.add(btnDone);
		
		//TextBoxes
		txtCounter = new JTextField();
		txtCounter.setText("0");
		txtCounter.setForeground(Color.GRAY);
		txtCounter.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtCounter.setColumns(10);
		txtCounter.setBackground(Color.WHITE);
		txtCounter.setBounds(292, 147, 32, 28);
		contentPane.add(txtCounter);
	}

}
