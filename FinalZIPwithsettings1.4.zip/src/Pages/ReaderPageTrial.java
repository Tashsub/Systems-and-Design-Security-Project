package Pages;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTable;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.table.DefaultTableModel;

import Systems.User;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;

public class ReaderPageTrial extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ReaderPageTrial frame = new ReaderPageTrial();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ReaderPageTrial() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(250, 100, 1500, 900);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		//LABELS
		JLabel lblReaderPage = new JLabel("Reader Page");
		lblReaderPage.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblReaderPage.setBounds(657, 13, 182, 91);
		contentPane.add(lblReaderPage);
		
		//BUTTONS
		
		//btnSignOut
		JButton btnSignOut = new JButton("Log Out");
		btnSignOut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				LogInPage l = new LogInPage();
				l.setVisible(true);
			}
		});
		btnSignOut.setFont(new Font("Tahoma", Font.PLAIN, 19));
		btnSignOut.setBounds(78, 48, 124, 45);
		contentPane.add(btnSignOut);
		
		JTextArea textArea = new JTextArea();
		textArea.setEditable(false);
		textArea.setBounds(78, 211, 563, 306);
		contentPane.add(textArea);
		
		JButton btnNewButton = new JButton("Display Articles");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				
				User user = new User();
			
					
					
					//textArea.setText(user.printArticlePage());
					//user.printArticlePage();
					
					textArea.setText("k");
					
				
				
				
			}
		});
		btnNewButton.setBounds(211, 52, 284, 39);
		contentPane.add(btnNewButton);
		
		
		
	}
}
