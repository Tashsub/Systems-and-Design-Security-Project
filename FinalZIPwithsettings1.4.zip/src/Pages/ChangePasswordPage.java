package Pages;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Systems.User;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;

public class ChangePasswordPage extends JFrame {

	private JPanel contentPane;
	private JTextField txtOldPass;
	private JPasswordField passwordField;
	private JPasswordField passwordConfirmField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ChangePasswordPage frame = new ChangePasswordPage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ChangePasswordPage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(800, 300, 450, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblChangePassword = new JLabel("Change Password");
		lblChangePassword.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblChangePassword.setBounds(140, 13, 165, 54);
		contentPane.add(lblChangePassword);
		
		JLabel lblOldPassword = new JLabel("Old Password");
		lblOldPassword.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblOldPassword.setBounds(152, 80, 165, 54);
		contentPane.add(lblOldPassword);
		
		JLabel lblNewPassword = new JLabel("New Password");
		lblNewPassword.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewPassword.setBounds(152, 172, 165, 54);
		contentPane.add(lblNewPassword);
		
		JLabel lblConfirmNewPassword = new JLabel("Confirm New Password");
		lblConfirmNewPassword.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblConfirmNewPassword.setBounds(110, 264, 224, 54);
		contentPane.add(lblConfirmNewPassword);
		
		JLabel lblErrors = new JLabel("");
		lblErrors.setHorizontalAlignment(SwingConstants.CENTER);
		lblErrors.setForeground(Color.RED);
		lblErrors.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblErrors.setBounds(31, 352, 390, 31);
		contentPane.add(lblErrors);
		
		txtOldPass = new JTextField();
		txtOldPass.setBounds(97, 131, 234, 34);
		contentPane.add(txtOldPass);
		txtOldPass.setColumns(10);
		
		JButton btnChange = new JButton("Change");
		btnChange.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				RegisterPage user = new RegisterPage();
				User userU= new User();
				 
				int oldPassword = txtOldPass.getText().hashCode();
				String password = passwordField.getText();; 
				String confirmPassword = passwordConfirmField.getText();
				int oldPassExist;
				
				
				try {
					oldPassExist = userU.checkUserPassword(LogInPage.currentUser);
					
					
					if( txtOldPass.getText() == null|| passwordField.getText() == null || passwordConfirmField.getText() == null) {
						lblErrors.setText( "Fill in all fields" );
						
					}else if(oldPassExist == 0) {
						lblErrors.setText( "Old password does not exist" );
						
					
					}else if(user.isPasswordValid(passwordField.getText()) == false ){
							lblErrors.setText( "Ensure your password has one UpperCase letter, 5-15 characters and 1 number" );
							
					}else if(passwordField.getText().equals(passwordConfirmField.getText()) == false ) {
						lblErrors.setText( "Make sure passwords match" );
						
							System.out.println(passwordField.getText());
							System.out.println(passwordConfirmField.getText());
					}else if ((passwordField.getText().equals(passwordConfirmField.getText()) == true ) && (user.isPasswordValid(passwordConfirmField.getText()) == true)) {
						//update user password to database for the current login
						try {
							userU.update("User",  "Password" ,confirmPassword.hashCode() , "LoginID", LogInPage.currentUser);
							
							JOptionPane.showMessageDialog(null, "Please Login with your new Password", "Problem!", JOptionPane.INFORMATION_MESSAGE);
							
							
						} catch (ClassNotFoundException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
					
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			    dispose();
				LogInPage l = new LogInPage();
				l.setVisible(true);
				dispose();
				
				
			}
		});
		btnChange.setFont(new Font("Tahoma", Font.PLAIN, 17));
		btnChange.setBounds(168, 385, 97, 25);
		contentPane.add(btnChange);
		
		
		
		passwordField = new JPasswordField();
		passwordField.setBounds(97, 224, 234, 34);
		contentPane.add(passwordField);
		
		passwordConfirmField = new JPasswordField();
		passwordConfirmField.setBounds(100, 311, 234, 34);
		contentPane.add(passwordConfirmField);
	}

}
