package Pages; 
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.border.EmptyBorder;

import Systems.User;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class AddAuthorPage extends JFrame {

	private JPanel contentPane;
	private JTextField txtEmailExist;
	private JTextField txtForename;
	private JTextField txtSurname;
	private JTextField txtUni;
	private JTextField txtEmail;
	private JTextField txtConfEmail;
	private JTextField txtPass;
	private JTextField txtConfPass;
	public static int i;
	private JPasswordField passwordField;
	private JPasswordField passwordConfirmField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AddAuthorPage frame = new AddAuthorPage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AddAuthorPage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(650, 250, 700, 830);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		//LABELS
		JLabel labelTitle = new JLabel("Add Author to the Board");
		labelTitle.setFont(new Font("Tahoma", Font.PLAIN, 25));
		labelTitle.setBounds(201, 30, 284, 51);
		contentPane.add(labelTitle);
		
		JLabel labelHeading = new JLabel("Already registered user");
		labelHeading.setFont(new Font("Tahoma", Font.PLAIN, 23));
		labelHeading.setBounds(214, 94, 271, 51);
		contentPane.add(labelHeading);
		
		JLabel labelEmail = new JLabel("Email  :");
		labelEmail.setFont(new Font("Tahoma", Font.PLAIN, 22));
		labelEmail.setBounds(161, 169, 91, 23);
		contentPane.add(labelEmail);
		
		JLabel labelTitle2 = new JLabel("Title :");
		labelTitle2.setFont(new Font("Tahoma", Font.PLAIN, 22));
		labelTitle2.setBounds(244, 360, 72, 23);
		contentPane.add(labelTitle2);
		
		JLabel labelForname = new JLabel("Forename : ");
		labelForname.setFont(new Font("Tahoma", Font.PLAIN, 22));
		labelForname.setBounds(187, 408, 127, 23);
		contentPane.add(labelForname);
		
		JLabel labelSurname = new JLabel("Surname : ");
		labelSurname.setFont(new Font("Tahoma", Font.PLAIN, 22));
		labelSurname.setBounds(197, 452, 117, 23);
		contentPane.add(labelSurname);
		
		JLabel labelUni = new JLabel("University affiliation : ");
		labelUni.setFont(new Font("Tahoma", Font.PLAIN, 22));
		labelUni.setBounds(92, 494, 226, 23);
		contentPane.add(labelUni);
		
		JLabel LabelEmail2 = new JLabel("Email  :");
		LabelEmail2.setFont(new Font("Tahoma", Font.PLAIN, 22));
		LabelEmail2.setBounds(225, 540, 91, 23);
		contentPane.add(LabelEmail2);
		
		JLabel labelConfEmail = new JLabel("Confirm Email  :");
		labelConfEmail.setFont(new Font("Tahoma", Font.PLAIN, 22));
		labelConfEmail.setBounds(142, 581, 167, 23);
		contentPane.add(labelConfEmail);
		
		JLabel labelPass = new JLabel("Password :");
		labelPass.setFont(new Font("Tahoma", Font.PLAIN, 22));
		labelPass.setBounds(191, 628, 119, 23);
		contentPane.add(labelPass);
		
		JLabel labelConfPass = new JLabel("Confirm Password :");
		labelConfPass.setFont(new Font("Tahoma", Font.PLAIN, 22));
		labelConfPass.setBounds(108, 673, 189, 23);
		contentPane.add(labelConfPass);
		
		JLabel labelHeading2 = new JLabel("Non-registered user");
		labelHeading2.setFont(new Font("Tahoma", Font.PLAIN, 23));
		labelHeading2.setBounds(222, 285, 271, 51);
		contentPane.add(labelHeading2);
		
		//COMBOBOX
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Mr", "Mrs", "Dr", "Prof"}));
		comboBox.setMaximumRowCount(4);
		comboBox.setBounds(328, 360, 97, 31);
		contentPane.add(comboBox);
		
		//TEXTBOXES
		txtEmailExist = new JTextField();
		txtEmailExist.setFont(new Font("Tahoma", Font.PLAIN, 21));
		txtEmailExist.setColumns(10);
		txtEmailExist.setBounds(264, 165, 271, 31);
		contentPane.add(txtEmailExist);
		
		txtForename = new JTextField();
		txtForename.setFont(new Font("Tahoma", Font.PLAIN, 21));
		txtForename.setColumns(10);
		txtForename.setBounds(326, 404, 178, 31);
		contentPane.add(txtForename);
		
		txtSurname = new JTextField();
		txtSurname.setFont(new Font("Tahoma", Font.PLAIN, 21));
		txtSurname.setColumns(10);
		txtSurname.setBounds(326, 448, 178, 31);
		contentPane.add(txtSurname);
		
		txtUni = new JTextField();
		txtUni.setFont(new Font("Tahoma", Font.PLAIN, 21));
		txtUni.setColumns(10);
		txtUni.setBounds(328, 492, 271, 31);
		contentPane.add(txtUni);
		
		txtEmail = new JTextField();
		txtEmail.setFont(new Font("Tahoma", Font.PLAIN, 21));
		txtEmail.setColumns(10);
		txtEmail.setBounds(328, 536, 271, 31);
		contentPane.add(txtEmail);
		
		txtConfEmail = new JTextField();
		txtConfEmail.setFont(new Font("Tahoma", Font.PLAIN, 21));
		txtConfEmail.setColumns(10);
		txtConfEmail.setBounds(328, 580, 271, 31);
		contentPane.add(txtConfEmail);
		
		JLabel lblErrors = new JLabel("");
		lblErrors.setHorizontalAlignment(SwingConstants.CENTER);
		lblErrors.setForeground(Color.RED);
		lblErrors.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblErrors.setBounds(54, 715, 588, 31);
		contentPane.add(lblErrors);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(328, 623, 271, 41);
		contentPane.add(passwordField);
		
		passwordConfirmField = new JPasswordField();
		passwordConfirmField.setBounds(328, 668, 271, 41);
		contentPane.add(passwordConfirmField);
		
		//BUTTONS
		
		
		User k = new User();
		
		
		//btnAddAuthor
		JButton btnAddAuthor = new JButton("ADD");
		btnAddAuthor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				i++;
				ArticleAddedPage.txtCounter.setText(Integer.toString(i));
				dispose();
				
				String loginID = txtEmailExist.getText();
				//String coAuthorName = k.getValue("User", "LoginID", loginID, "Forename");

				int submissionID;
				String coAuthorName; 
				String authorLoginID = txtEmailExist.getText();
				String authorLoginIDFromSignUP; 
				
				//get submission ID and coAuthorName
				
				try {
					
					coAuthorName = k.getValueString("User", "LoginID",loginID , "Forename");
					
			
					submissionID = k.getValueInt("Submission", "MainAuthor", LogInPage.currentUser,  "SubmissionID" );
					
					if( k.checkEmailExists(loginID) == true ){
						
						k.insertCoAuthorsData(authorLoginID, submissionID, 0);
						
						User.update("User", "IsAuthor", 1, "LoginID ",authorLoginID );
						
						
						
					}else {
						lblErrors.setText("Email does not exits please sign up");
					}
					

				} catch (SQLException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
				
				
				
				
			}
		});
		btnAddAuthor.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnAddAuthor.setBounds(274, 221, 97, 31);
		contentPane.add(btnAddAuthor);
		
		//btnAddAuthorNon
		JButton btnAddAuthorNon = new JButton("ADD");
		btnAddAuthorNon.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				
				String title ;
				String value = comboBox.getSelectedItem().toString();
				
				if( value == "Mr") {
					title = "Mr";
				}else if(value ==  "Mrs") {
					title = "Mrs";
				}else if (value == "Dr") {
					title = "Dr";
				}else if (value=="Prof") {
					title = "Prof";
				}else{
					title = "none";
					lblErrors.setText("Please select your Title"); 
				}
				
				String forname = txtForename.getText();
				String surname = txtSurname.getText(); 
				String university = txtUni.getText();
				String email = txtEmail.getText(); 
				String confirmEmail = txtConfEmail.getText();
				String password = passwordField.getText();; 
				String confirmPassword = passwordConfirmField.getText();
				
				//System.out.println(title);
				//Set all to false to initialise
				boolean author = true; 
				boolean reviewer = false; 
				boolean editor = false; 
				

				//change the value of the user 
				if (LogInPage.register == true) {
					author = true; 
				}else if (LogInPage.register == false) {
					editor = true; 
				} 
				
				RegisterPage a = new RegisterPage();
				User newU = new User();
					
				//check all the fields have been completed
				//if all fields are not null then sign up user 
				if( a.isNull(forname) == true )   {
					lblErrors.setText("Please enter a valid Forname");
				}else if ( a.isNull(surname) == true  ) {
					lblErrors.setText("Please enter a valid Surname");
				}else if (a.isNull(university) == true ) {
					lblErrors.setText("Please enter a valid University");
				}else if  ( a.validateEmail(email)== false ) {
					lblErrors.setText("Please enter a valid Email");
				}else if (a.isNull(password) == true) {
					lblErrors.setText("Please enter a Password");
				}else if( a.isPasswordValid(password) == false) {
					lblErrors.setText( "Ensure your password has one UpperCase letter, 5-12 characters and 1 number" );
				}else if(a.isNull(confirmPassword)) {
					lblErrors.setText("Please confirm Password");
				}else if(email.equals(confirmEmail)==false) {
					lblErrors.setText("Please make sure both emails match");
				}else if(password.equals(confirmPassword)==false) {
					lblErrors.setText( "Please make sure both passowords match" );
				} else
					try {
						if(newU.checkEmailExists(email) == true) {
							lblErrors.setText( "This email is already in use" );
						}
					} catch (SQLException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
						
						
				//This is the final check the login page will have to pass
				//if all the fields in the login are not null and satisfy the above 
				//then the user will be allowed to sign up as a user
				
				try {
					if( (a.isNull(forname) == false  && a.isNull(surname) ==false   && a.isNull(university) == false  && a.validateEmail(email)== true && a.isNull(password) == false
							&& a.isPasswordValid(password) == true && (a.isNull(confirmEmail)== false && email.equals(confirmEmail)==true) && password.equals(confirmPassword)==true) && newU.checkEmailExists(email) == false
							){
						lblErrors.setForeground(Color.black);
						lblErrors.setText("Thank You For Signing Up User");
					}
				} catch (SQLException e2) {
				
					e2.printStackTrace();
				}
				

				//execute the query and add data into the data base over here
				//meaning everything check out and user can finally be registered
				
				if(lblErrors.getText().equals("Thank You For Signing Up User")) {
					//create a user
					User pushData = new User(); 
					
					
					
					try {
						
						//push data into DB
						pushData.insertUserData(title, forname, surname, university, email, confirmPassword.hashCode(), reviewer, editor, author);
						
						int submissionID = k.getValueInt("Submission", "MainAuthor", LogInPage.currentUser,  "SubmissionID" );
						
						k.insertCoAuthorsData(email, submissionID , 0);
						
						
						
					} catch (ClassNotFoundException | SQLException e1) {
						e1.printStackTrace();
					}
							
					i++;
					ArticleAddedPage.txtCounter.setText(Integer.toString(i));
					dispose();
				
				}
				
				
				
			}
		});
		btnAddAuthorNon.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnAddAuthorNon.setBounds(274, 748, 97, 31);
		contentPane.add(btnAddAuthorNon);
		
		JButton btnExit = new JButton("exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
			}
		});
		btnExit.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnExit.setBounds(33, 48, 84, 33);
		contentPane.add(btnExit);
		
	}

}
