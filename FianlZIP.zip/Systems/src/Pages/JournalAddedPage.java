package Pages;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;

public class JournalAddedPage extends JFrame {

	private JPanel contentPane;
	public static JTextField txtCount;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					JournalAddedPage frame = new JournalAddedPage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public JournalAddedPage() {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(600, 20, 800, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		//LABELS
		JLabel labeltext = new JLabel("Board Editors added until now");
		labeltext.setForeground(Color.GRAY);
		labeltext.setFont(new Font("Tahoma", Font.PLAIN, 19));
		labeltext.setBounds(318, 139, 333, 40);
		contentPane.add(labeltext);
		
		JLabel labelQuestion = new JLabel("Do you want to add a board of editors for the Journal that you just added?");
		labelQuestion.setFont(new Font("Tahoma", Font.PLAIN, 19));
		labelQuestion.setBounds(61, 68, 664, 49);
		contentPane.add(labelQuestion);
		
		JLabel labelTitle = new JLabel("Your Journal has been added!");
		labelTitle.setFont(new Font("Tahoma", Font.PLAIN, 23));
		labelTitle.setBounds(222, 13, 343, 42);
		contentPane.add(labelTitle);
		
		//BUTTONS
		//btnAddBoard
		JButton btnAddBoard = new JButton("ADD");
		btnAddBoard.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AddEditorPage a = new AddEditorPage();
				a.setVisible(true);
			}
		});
		
		txtCount = new JTextField();
		txtCount.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtCount.setForeground(Color.GRAY);
		txtCount.setBackground(Color.WHITE);
		txtCount.setText("0");
		txtCount.setBounds(281, 148, 32, 28);
		contentPane.add(txtCount);
		txtCount.setColumns(10);
		btnAddBoard.setFont(new Font("Tahoma", Font.PLAIN, 21));
		btnAddBoard.setBounds(184, 138, 85, 42);
		contentPane.add(btnAddBoard);
		
		//btnDone
		JButton btnDone = new JButton("DONE");
		btnDone.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				LogInPage l = new LogInPage();
				l.setVisible(true);
			}
		});
		btnDone.setFont(new Font("Tahoma", Font.PLAIN, 21));
		btnDone.setBounds(294, 198, 143, 42);
		contentPane.add(btnDone);
		
		
	}

}
