package Pages;
import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTable;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.table.DefaultTableModel;

import Systems.User;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;

public class ReaderPage extends JFrame {
	
	
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
    static final String DB_URL = "jdbc:mysql://stusql.dcs.shef.ac.uk/team037";
    static final String USER = "team037";
    static final String PASS = "d84f5e63";
    static Connection conn = null;
    static Statement stmt = null;
    private JTextArea textArea;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ReaderPage frame = new ReaderPage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ReaderPage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(250, 100, 1500, 900);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		//LABELS
		JLabel lblReaderPage = new JLabel("Reader Page");
		lblReaderPage.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblReaderPage.setBounds(657, 13, 182, 91);
		contentPane.add(lblReaderPage);
		
		//BUTTONS
		
		//btnSignOut
		JButton btnSignOut = new JButton("Log Out");
		btnSignOut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				LogInPage l = new LogInPage();
				l.setVisible(true);
			}
		});
		btnSignOut.setFont(new Font("Tahoma", Font.PLAIN, 19));
		btnSignOut.setBounds(78, 48, 124, 45);
		contentPane.add(btnSignOut);
		
		
		JTextArea textArea = new JTextArea();
		textArea.setEditable(false);
		textArea.setBounds(201, 190, 1054, 385);
		
		textArea.append("Title \t     JournalISSN \t Volume \t Edition \t PageNum \t ChiefEditor\n");
		
		
		try {
			openConnection();
		       ResultSet res = stmt.executeQuery("SELECT * FROM Journal");
		//  	      System.out.format("%50s%50s%50s%50s%100s%50s\n", "Title", "JournalISSN", "Volume", "Edition", "PageNum", "ChiefEditor");
		       while (res.next()) {
		       	String title = res.getString("title");
			        int journalISSN = res.getInt("journalISSN");
			        String volume = res.getString("volume");
			        String edition = res.getString("edition");
			        int pageNum = res.getInt("pageNum");
			        String chiefEditor = res.getString("chiefEditor");
			        textArea.append(title +"\t"+journalISSN+"\t"+volume+"\t"+edition+"\t"+pageNum+"\t"+chiefEditor+"\n"); 
			        
			  //      System.out.format("%50s%50d%50s%50s%100d%50s\n", title, journalISSN, volume, edition, pageNum, chiefEditor);
		       }
		   res.close();
		} catch (ClassNotFoundException | SQLException e1) {
			
			e1.printStackTrace();
		
		}
		contentPane.add(textArea);
		
			
		
	}
	  public static void openConnection() throws SQLException, ClassNotFoundException {
	  		Class.forName("org.gjt.mm.mysql.Driver");
	  		conn = DriverManager.getConnection(DB_URL, USER, PASS);
	  		stmt = conn.createStatement();
	  	}
}
