package Pages;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Systems.User;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.HeadlessException;

import javax.swing.JTextArea;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DropMode;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JComboBox;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;

public class EditorAddJournalPage extends JFrame {

	private JPanel contentPane;
	private JTextField txtIssn;
	private JTextField txtEmailExist;
	private JTextField txtForename;
	private JTextField txtSurname;
	private JTextField txtUni;
	private JTextField txtEmail;
	private JTextField txtConfEmail;
	private JTextField txtCounter;
	private int g;
	public static int al;
	private JPasswordField passwordField;
	private JPasswordField passwordConfirmField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EditorAddJournalPage frame = new EditorAddJournalPage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public EditorAddJournalPage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(330, 40, 1300, 1000);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel labelAddNewJournal = new JLabel("Add new Journal");
		labelAddNewJournal.setFont(new Font("Tahoma", Font.PLAIN, 25));
		labelAddNewJournal.setBounds(205, 112, 199, 51);
		contentPane.add(labelAddNewJournal);
		
		JLabel labelTitle = new JLabel("Title : ");
		labelTitle.setFont(new Font("Tahoma", Font.PLAIN, 21));
		labelTitle.setBounds(47, 167, 61, 26);
		contentPane.add(labelTitle);
		
		JTextArea txtTitle = new JTextArea();
		txtTitle.setRows(10);
		txtTitle.setLineWrap(true);
		txtTitle.setFont(new Font("Tahoma", Font.PLAIN, 18));
		txtTitle.setDropMode(DropMode.INSERT);
		txtTitle.setColumns(10);
		txtTitle.setBounds(47, 206, 508, 45);
		contentPane.add(txtTitle);
		
		txtIssn = new JTextField();
		txtIssn.setToolTipText("");
		txtIssn.setHorizontalAlignment(SwingConstants.LEFT);
		txtIssn.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtIssn.setColumns(10);
		txtIssn.setBounds(186, 278, 223, 40);
		contentPane.add(txtIssn);
		
		JLabel labelJournaliSsn = new JLabel("Journal ISSN : ");
		labelJournaliSsn.setFont(new Font("Tahoma", Font.PLAIN, 21));
		labelJournaliSsn.setBounds(47, 284, 142, 26);
		contentPane.add(labelJournaliSsn);
		
		JButton btnAddJournal = new JButton("ADD JOURNAL");
		btnAddJournal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				User user = new User();
				
				try {
					
					int journalISSN = Integer.parseInt(txtIssn.getText());
				
				
				if (txtTitle.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Title field is empty", "Problem!", JOptionPane.INFORMATION_MESSAGE);}
				else if (txtIssn.getText().contentEquals("")) {
					JOptionPane.showMessageDialog(null, "ISSN field is empty", "Problem!", JOptionPane.INFORMATION_MESSAGE);}
				//else if (here checks from database if journal ISSN can be found)(if it cannot be found) {
				//JOptionPane.showMessageDialog(null, "Journal Issn cannot be matched to an Issn that it already exists", "Problem!", JOptionPane.INFORMATION_MESSAGE);}
				else if( user.checkJournalISSNExists(journalISSN) == true) {
					JOptionPane.showMessageDialog(null, "ISSN already exists", "Problem!", JOptionPane.INFORMATION_MESSAGE);
				}else {
					
					String title = txtTitle.getText();
					
					String chiefEditor = LogInPage.currentUser;
					
					try {
						user.insertJournalData(title, journalISSN, " ", " ", 0, chiefEditor );
					} catch (ClassNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (SQLException e1) {
						
						e1.printStackTrace();
					}
					
				}
				} catch (HeadlessException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (NumberFormatException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				
				dispose();
				JOptionPane.showMessageDialog(null, "Journal added!", "Added!", JOptionPane.INFORMATION_MESSAGE);
				//(here after everything is okay the article can b submitted to the database)
				}
			}
		});
		btnAddJournal.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnAddJournal.setBounds(205, 361, 149, 45);
		contentPane.add(btnAddJournal);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBorder(new EmptyBorder(5, 5, 5, 5));
		panel.setBounds(601, 112, 682, 768);
		contentPane.add(panel);
		
		JLabel labelTitle3 = new JLabel("Add Author to the Board");
		labelTitle3.setFont(new Font("Tahoma", Font.PLAIN, 25));
		labelTitle3.setBounds(201, 30, 284, 51);
		panel.add(labelTitle3);
		
		JLabel labelAlreadyRegister = new JLabel("Already registered user");
		labelAlreadyRegister.setFont(new Font("Tahoma", Font.PLAIN, 23));
		labelAlreadyRegister.setBounds(214, 94, 271, 51);
		panel.add(labelAlreadyRegister);
		
		JLabel label_5 = new JLabel("Email  :");
		label_5.setFont(new Font("Tahoma", Font.PLAIN, 22));
		label_5.setBounds(161, 169, 91, 23);
		panel.add(label_5);
		
		JLabel label_6 = new JLabel("Title :");
		label_6.setFont(new Font("Tahoma", Font.PLAIN, 22));
		label_6.setBounds(244, 360, 72, 23);
		panel.add(label_6);
		
		JLabel label_7 = new JLabel("Forename : ");
		label_7.setFont(new Font("Tahoma", Font.PLAIN, 22));
		label_7.setBounds(187, 408, 127, 23);
		panel.add(label_7);
		
		JLabel label_8 = new JLabel("Surname : ");
		label_8.setFont(new Font("Tahoma", Font.PLAIN, 22));
		label_8.setBounds(197, 452, 117, 23);
		panel.add(label_8);
		
		JLabel label_9 = new JLabel("University affiliation : ");
		label_9.setFont(new Font("Tahoma", Font.PLAIN, 22));
		label_9.setBounds(92, 494, 226, 23);
		panel.add(label_9);
		
		JLabel label_10 = new JLabel("Email  :");
		label_10.setFont(new Font("Tahoma", Font.PLAIN, 22));
		label_10.setBounds(225, 540, 91, 23);
		panel.add(label_10);
		
		JLabel label_11 = new JLabel("Confirm Email  :");
		label_11.setFont(new Font("Tahoma", Font.PLAIN, 22));
		label_11.setBounds(142, 581, 167, 23);
		panel.add(label_11);
		
		JLabel label_12 = new JLabel("Password :");
		label_12.setFont(new Font("Tahoma", Font.PLAIN, 22));
		label_12.setBounds(191, 628, 119, 23);
		panel.add(label_12);
		
		JLabel label_13 = new JLabel("Confirm Password :");
		label_13.setFont(new Font("Tahoma", Font.PLAIN, 22));
		label_13.setBounds(108, 673, 189, 23);
		panel.add(label_13);
		
		JLabel labelTitle4 = new JLabel("Non-registered user");
		labelTitle4.setFont(new Font("Tahoma", Font.PLAIN, 23));
		labelTitle4.setBounds(222, 285, 271, 51);
		panel.add(labelTitle4);
		
		JLabel lblErrors = new JLabel("");
		lblErrors.setHorizontalAlignment(SwingConstants.CENTER);
		lblErrors.setForeground(Color.RED);
		lblErrors.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblErrors.setBounds(22, 256, 588, 31);
		panel.add(lblErrors);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Mr", "Mrs", "Dr", "Prof"}));
		comboBox.setMaximumRowCount(4);
		comboBox.setBounds(328, 360, 97, 31);
		panel.add(comboBox);
		
		txtEmailExist = new JTextField();
		txtEmailExist.setFont(new Font("Tahoma", Font.PLAIN, 21));
		txtEmailExist.setColumns(10);
		txtEmailExist.setBounds(264, 165, 271, 31);
		panel.add(txtEmailExist);
		
		txtForename = new JTextField();
		txtForename.setFont(new Font("Tahoma", Font.PLAIN, 21));
		txtForename.setColumns(10);
		txtForename.setBounds(326, 404, 178, 31);
		panel.add(txtForename);
		
		txtSurname = new JTextField();
		txtSurname.setFont(new Font("Tahoma", Font.PLAIN, 21));
		txtSurname.setColumns(10);
		txtSurname.setBounds(326, 448, 178, 31);
		panel.add(txtSurname);
		
		txtUni = new JTextField();
		txtUni.setFont(new Font("Tahoma", Font.PLAIN, 21));
		txtUni.setColumns(10);
		txtUni.setBounds(328, 492, 271, 31);
		panel.add(txtUni);
		
		txtEmail = new JTextField();
		txtEmail.setFont(new Font("Tahoma", Font.PLAIN, 21));
		txtEmail.setColumns(10);
		txtEmail.setBounds(328, 536, 271, 31);
		panel.add(txtEmail);
		
		txtConfEmail = new JTextField();
		txtConfEmail.setFont(new Font("Tahoma", Font.PLAIN, 21));
		txtConfEmail.setColumns(10);
		txtConfEmail.setBounds(328, 580, 271, 31);
		panel.add(txtConfEmail);
		
		
		User k = new User();
		
		JButton btnAdd = new JButton("ADD");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				g++;
				txtCounter.setText(Integer.toString(g));
				
				String loginID = txtEmailExist.getText();
				//String coAuthorName = k.getValue("User", "LoginID", loginID, "Forename");

				int journalISSN;
				String coEditorName; 
				String EditorLoginID = txtEmailExist.getText();
				String EditorLoginIDFromSignUP; 
				
				
				//get JournalISS ID
				try {
					//articleID = k.getValueInt("Article", "LoginID", LogInPage.currentUser,  "ArticleID" );
					coEditorName = k.getValueString("User", "LoginID",loginID , "Forename");
					
					journalISSN = k.getValueInt("Journal", "ChiefEditor", LogInPage.currentUser,  "JournalISSN" );
				
					if( k.checkEmailExists(loginID) == true ){
						
						k.insertCoEditorsData(journalISSN, EditorLoginID );
						
						//update user to editor now, to ensure they become an editor
						User.update("User", "IsEditor", 1 , "LoginID ",EditorLoginID );
						
						
						
					}else {
						lblErrors.setText("Email does not exits please sign up");
					}
					

				} catch (SQLException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
				
				
				
				
				
				
				
			}
		});
		btnAdd.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnAdd.setBounds(274, 208, 97, 31);
		panel.add(btnAdd);
		
		JButton btnAdd2 = new JButton("ADD");
		btnAdd2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				g++;
				txtCounter.setText(Integer.toString(g));
			}
		});
		btnAdd2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnAdd2.setBounds(274, 739, 97, 31);
		panel.add(btnAdd2);
		
		
		
		passwordField = new JPasswordField();
		passwordField.setBounds(328, 625, 271, 36);
		panel.add(passwordField);
		
		passwordConfirmField = new JPasswordField();
		passwordConfirmField.setBounds(328, 668, 271, 38);
		panel.add(passwordConfirmField);
		
		JButton btnAddEditorNon = new JButton("ADD");
		btnAddEditorNon.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				

				String title ;
				String value = comboBox.getSelectedItem().toString();
				
				if( value == "Mr") {
					title = "Mr";
				}else if(value ==  "Mrs") {
					title = "Mrs";
				}else if (value == "Dr") {
					title = "Dr";
				}else if (value=="Prof") {
					title = "Prof";
				}else{
					title = "none";
					lblErrors.setText("Please select your Title"); 
				}
				
				
				String forname = txtForename.getText();
				String surname = txtSurname.getText(); 
				String university = txtUni.getText();
				String email = txtEmail.getText(); 
				String confirmEmail = txtConfEmail.getText();
				String password = passwordField.getText();; 
				String confirmPassword = passwordConfirmField.getText();
				int journalISSN;
				
				String loginID = txtEmailExist.getText();
				String coEditorName; 
				String EditorLoginID = txtEmailExist.getText();
				String EditorLoginIDFromSignUP; 
				
				
				//System.out.println(title);
				//Set all to false to initialise
				boolean author = false; 
				boolean reviewer = false; 
				boolean editor = true; 
				

				//change the value of the user 
				if (LogInPage.register == true) {
					author = true; 
				}else if (LogInPage.register == false) {
					editor = true; 
				} 
				
				RegisterPage a = new RegisterPage();
				User newU = new User();
					
				//check all the fields have been completed
				//if all fields are not null then sign up user 
				if( a.isNull(forname) == true )   {
					lblErrors.setText("Please enter a valid Forname");
				}else if ( a.isNull(surname) == true  ) {
					lblErrors.setText("Please enter a valid Surname");
				}else if (a.isNull(university) == true ) {
					lblErrors.setText("Please enter a valid University");
				}else if  ( a.validateEmail(email)== false ) {
					lblErrors.setText("Please enter a valid Email");
				}else if (a.isNull(password) == true) {
					lblErrors.setText("Please enter a Password");
				}else if( a.isPasswordValid(password) == false) {
					lblErrors.setText( "Ensure your password has one UpperCase letter, 5-12 characters and 1 number" );
				}else if(a.isNull(confirmPassword)) {
					lblErrors.setText("Please confirm Password");
				}else if(email.equals(confirmEmail)==false) {
					lblErrors.setText("Please make sure both emails match");
				}else if(password.equals(confirmPassword)==false) {
					lblErrors.setText( "Please make sure both passowords match" );
				} else
					try {
						if(newU.checkEmailExists(email) == true) {
							lblErrors.setText( "This email is already in use" );
						}
					} catch (SQLException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
						
						
				//This is the final check the login page will have to pass
				//if all the fields in the login are not null and satisfy the above 
				//then the user will be allowed to sign up as a user
				
				try {
					if( (a.isNull(forname) == false  && a.isNull(surname) ==false   && a.isNull(university) == false  && a.validateEmail(email)== true && a.isNull(password) == false
							&& a.isPasswordValid(password) == true && (a.isNull(confirmEmail)== false && email.equals(confirmEmail)==true) && password.equals(confirmPassword)==true) && newU.checkEmailExists(email) == false
							){
						lblErrors.setForeground(Color.black);
						lblErrors.setText("Thank You For Signing Up User");
					}
				} catch (SQLException e2) {
				
					e2.printStackTrace();
				}
				

				//execute the query and add data into the data base over here
				//meaning everything check out and user can finally be registered
				
				if(lblErrors.getText().equals("Thank You For Signing Up User")) {
					//create a user
					User pushData = new User(); 
					
					
					
					try {
						coEditorName = k.getValueString("User", "LoginID",loginID , "Forename");
						
						journalISSN = k.getValueInt("Journal", "ChiefEditor", LogInPage.currentUser,  "JournalISSN" );
						
						//push data into DB
						pushData.insertUserData(title, forname, surname, university, email, confirmPassword.hashCode(), reviewer, editor, author);
						
						
						
						k.insertCoEditorsData(journalISSN, email );
						
						
						
						
					} catch (ClassNotFoundException | SQLException e1) {
						e1.printStackTrace();
					}
					

					al++;
					txtCounter.setText(Integer.toString(al));
					dispose();	
					
				}
				
	
				
			}
		});
		btnAddEditorNon.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnAddEditorNon.setBounds(264, 711, 97, 31);
		panel.add(btnAddEditorNon);
		
		JLabel lblBoardEditorsAdded = new JLabel("Board Editors added until now");
		lblBoardEditorsAdded.setForeground(Color.GRAY);
		lblBoardEditorsAdded.setFont(new Font("Tahoma", Font.PLAIN, 19));
		lblBoardEditorsAdded.setBounds(825, 69, 333, 40);
		contentPane.add(lblBoardEditorsAdded);
		
		txtCounter = new JTextField();
		txtCounter.setText("0");
		txtCounter.setForeground(Color.GRAY);
		txtCounter.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtCounter.setColumns(10);
		txtCounter.setBackground(Color.WHITE);
		txtCounter.setBounds(781, 77, 32, 28);
		contentPane.add(txtCounter);
		
		JLabel labelTitle2 = new JLabel("Add Editor to the Board");
		labelTitle2.setFont(new Font("Tahoma", Font.PLAIN, 25));
		labelTitle2.setBounds(789, 6, 284, 51);
		contentPane.add(labelTitle2);
		
		JButton btnExit = new JButton("exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnExit.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnExit.setBounds(12, 35, 84, 33);
		contentPane.add(btnExit);
	}

}