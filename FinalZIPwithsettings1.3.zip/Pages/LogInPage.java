package Pages; 
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Systems.User;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;

public class LogInPage extends JFrame {

	private JPanel contentPane;
	private JTextField txtUsername;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	
	//global variable used to remember what the user pressed on the LoginPage
	//And then will be taken to register page 
	public static boolean register;
	
	private JPasswordField passwordField;
	
	//change the state of user to know which user is using the system
	public static String currentUser; 
	
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LogInPage frame = new LogInPage();
					frame.setVisible(true);
					frame.setResizable(false);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LogInPage() {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 750, 750);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBorder(new EmptyBorder(5, 5, 5, 5));
		panel.setBounds(0, 0, 732, 703);
		contentPane.add(panel);

		//LABELS
		JLabel labelLogIn = new JLabel("Log In ");
		labelLogIn.setFont(new Font("Tahoma", Font.PLAIN, 41));
		labelLogIn.setBounds(309, 54, 129, 50);
		panel.add(labelLogIn);
		
		JLabel label_1 = new JLabel("Password :");
		label_1.setForeground(Color.GRAY);
		label_1.setFont(new Font("Tahoma", Font.PLAIN, 24));
		label_1.setBounds(123, 262, 117, 31);
		panel.add(label_1);
		
		JLabel lblEmail = new JLabel("Email :");
		lblEmail.setForeground(Color.GRAY);
		lblEmail.setFont(new Font("Tahoma", Font.PLAIN, 24));
		lblEmail.setBounds(168, 212, 78, 31);
		panel.add(lblEmail);
		
		JLabel labelLogInAs = new JLabel("Log In as :");
		labelLogInAs.setFont(new Font("Tahoma", Font.PLAIN, 25));
		labelLogInAs.setBounds(244, 321, 129, 38);
		panel.add(labelLogInAs);
		
		JLabel label_4 = new JLabel("Register :");
		label_4.setForeground(Color.GRAY);
		label_4.setFont(new Font("Tahoma", Font.PLAIN, 24));
		label_4.setBounds(123, 563, 109, 31);
		panel.add(label_4);
		
		JLabel lblErrors = new JLabel("");
		lblErrors.setHorizontalAlignment(SwingConstants.CENTER);
		lblErrors.setBounds(102, 486, 554, 25);
		panel.add(lblErrors);
		
		//TEXTBOXES
		txtUsername = new JTextField();
		txtUsername.setForeground(Color.BLACK);
		txtUsername.setFont(new Font("Tahoma", Font.PLAIN, 24));
		txtUsername.setColumns(10);
		txtUsername.setBounds(244, 208, 243, 38);
		panel.add(txtUsername);
		
		//RADIOBUTTONS
		JRadioButton radioAuthor = new JRadioButton("Author");
		radioAuthor.setSelected(true);
		buttonGroup.add(radioAuthor);
		radioAuthor.setFont(new Font("Tahoma", Font.PLAIN, 21));
		radioAuthor.setBounds(381, 333, 127, 25);
		panel.add(radioAuthor);
		
		JRadioButton radioEditor = new JRadioButton("Editor");
		buttonGroup.add(radioEditor);
		radioEditor.setFont(new Font("Tahoma", Font.PLAIN, 21));
		radioEditor.setBounds(381, 367, 127, 25);
		panel.add(radioEditor);
		
		JRadioButton radioReviewer = new JRadioButton("Reviewer");
		buttonGroup.add(radioReviewer);
		radioReviewer.setFont(new Font("Tahoma", Font.PLAIN, 21));
		radioReviewer.setBounds(381, 397, 127, 25);
		panel.add(radioReviewer);
		
		
		
		//BUTTONS
		//BtnLogIn
		JButton btnLogIn = new JButton("Log In");
		btnLogIn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			
				
				
				//if username or password field are empty then alert user
				if (txtUsername.getText().equals("")|| passwordField.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Username or Password field is empty", "Problem!", JOptionPane.INFORMATION_MESSAGE);}
				
				String username = txtUsername.getText();
				
				int password = passwordField.getText().hashCode();
				
				
				User user = new User();
				
				
				/*
				 * 
				 * checks whether the username exists in the password and if it does then checks whether that password for the username
				 * matches the password in the input field 
				 * 
				 */
				
				
				
				try {
					if(user.checkEmailExists(username) == true && user.checkUserPassword(username) == password && 
							radioAuthor.isSelected() && user.isAuthor(username) == true 
							) {
						currentUser = username;
						//direct them to the author page
						//System.out.println("Username exists " + user.checkEmailExists(username));
						AuthorPage a = new AuthorPage();
						a.setVisible(true);
						dispose();
					
					}else if (user.checkEmailExists(username) ==true && user.checkUserPassword(username) ==password &&
							radioEditor.isSelected() && user.isEditor(username) == true 
							){
						currentUser = username;
						EditorPage editor =new EditorPage();
						editor.setVisible(true);
						dispose();	
					}else if (user.checkEmailExists(username) ==true && user.checkUserPassword(username) == password &&
							radioReviewer.isSelected() && user.isReviewer(username) == true 
							) {
						currentUser = username;
						ReviewerPage r = new ReviewerPage();
						r.setVisible(true);
						dispose();
					
					}else if(user.checkEmailExists(username) == false){
						lblErrors.setText("UserName does not exist");
						
					
						
						
					}else if(user.checkUserPassword(username) != Integer.valueOf(password) ) {
						lblErrors.setText("Please make sure username and password are correct");
						//System.out.println("user input" + password );
						//System.out.println("DB " + user.checkUserPassword(username));
					}
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
										
			}});
		btnLogIn.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnLogIn.setBounds(309, 441, 109, 38);
		panel.add(btnLogIn);
		
		//BtnSubmitAricle
		JButton btnSubmit = new JButton("Submit new Article");
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				register = true;
				RegisterPage r = new RegisterPage();
				r.setVisible(true);
				dispose();
			}
		});
		btnSubmit.setFont(new Font("Tahoma", Font.PLAIN, 23));
		btnSubmit.setBounds(244, 523, 243, 50);
		panel.add(btnSubmit);
		
		//btnAddJournal
		JButton btnAdd = new JButton("Add new Journal");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				register = false;
				dispose();
				RegisterPage r = new RegisterPage();
				r.setVisible(true);	
			}
		});
		btnAdd.setFont(new Font("Tahoma", Font.PLAIN, 23));
		btnAdd.setBounds(244, 585, 243, 50);
		panel.add(btnAdd);
		
		//btnLogInReader
		JButton btnLogInReader = new JButton("Log In as a Reader");
		btnLogInReader.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				ReaderPage ed = new ReaderPage();
				ed.setVisible(true);
				
			
				
			}
		});
		btnLogInReader.setFont(new Font("Tahoma", Font.PLAIN, 23));
		btnLogInReader.setBounds(244, 134, 243, 50);
		panel.add(btnLogInReader);
		
		//btnExit
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int response = JOptionPane.showConfirmDialog(null,"are you sure?","confirm",JOptionPane.YES_NO_OPTION);
				if ( response == JOptionPane.YES_OPTION) {
				System.exit(0);
				}
			}
			
		});
		btnExit.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnExit.setBounds(334, 652, 78, 38);
		panel.add(btnExit);
		
		//password field to censor text 
		passwordField = new JPasswordField();
		passwordField.setBounds(244, 262, 243, 38);
		panel.add(passwordField);
		
		
		
	}
}
