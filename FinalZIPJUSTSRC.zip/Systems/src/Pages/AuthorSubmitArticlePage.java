package Pages;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Systems.User;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.HeadlessException;

import javax.swing.JTextArea;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DropMode;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.JComboBox;
import javax.swing.JPasswordField;

public class AuthorSubmitArticlePage extends JFrame {

	private JPanel contentPane;
	private JTextField txtIssn;
	public static JTextField txtCounter;
	private JTextField txtEmailExist;
	private JTextField txtForename;
	private JTextField txtSurname;
	private JTextField txtUni;
	private JTextField txtEmail;
	private JTextField txtConfEmail;
	private int x;
	private JPasswordField passwordField;
	private JPasswordField passwordConfirmField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AuthorSubmitArticlePage frame = new AuthorSubmitArticlePage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AuthorSubmitArticlePage() {
		setBackground(new Color(238, 238, 238));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(330, 40, 1400, 1000);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(238, 238, 238));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		//LABELS
		JLabel labelTitle2 = new JLabel("Submit Article Page");
		labelTitle2.setFont(new Font("Tahoma", Font.PLAIN, 25));
		labelTitle2.setBounds(227, 30, 229, 53);
		contentPane.add(labelTitle2);
		
		JLabel labelTitle = new JLabel("Title : ");
		labelTitle.setFont(new Font("Tahoma", Font.PLAIN, 21));
		labelTitle.setBounds(24, 112, 61, 26);
		contentPane.add(labelTitle);
		
		JLabel labelAbstract = new JLabel("Abstract : ");
		labelAbstract.setFont(new Font("Tahoma", Font.PLAIN, 21));
		labelAbstract.setBounds(24, 208, 98, 26);
		contentPane.add(labelAbstract);
		
		JLabel labelISsn = new JLabel("Journal ISSN : ");
		labelISsn.setFont(new Font("Tahoma", Font.PLAIN, 21));
		labelISsn.setBounds(160, 676, 142, 26);
		contentPane.add(labelISsn);
		
		JLabel label = new JLabel("Do you want to add a board of authors for the Article that you just submitted?");
		label.setFont(new Font("Tahoma", Font.PLAIN, 19));
		label.setBounds(682, 6, 664, 49);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("Board Authors added until now");
		label_1.setForeground(Color.GRAY);
		label_1.setFont(new Font("Tahoma", Font.PLAIN, 19));
		label_1.setBounds(896, 55, 333, 40);
		contentPane.add(label_1);
		
		//txtCounter changes when an author is added to the board
		txtCounter = new JTextField();
		txtCounter.setText("0");
		txtCounter.setForeground(Color.GRAY);
		txtCounter.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtCounter.setColumns(10);
		txtCounter.setBackground(Color.WHITE);
		txtCounter.setBounds(858, 63, 32, 28);
		contentPane.add(txtCounter);
		
		//TEXTBOXES
		JTextArea txtTitle = new JTextArea();
		txtTitle.setRows(10);
		txtTitle.setLineWrap(true);
		txtTitle.setFont(new Font("Tahoma", Font.PLAIN, 18));
		txtTitle.setDropMode(DropMode.INSERT);
		txtTitle.setColumns(10);
		txtTitle.setBounds(24, 146, 631, 45);
		contentPane.add(txtTitle);
		
		JTextArea txtAbstract = new JTextArea();
		txtAbstract.setRows(10);
		txtAbstract.setLineWrap(true);
		txtAbstract.setFont(new Font("Tahoma", Font.PLAIN, 18));
		txtAbstract.setDropMode(DropMode.INSERT);
		txtAbstract.setColumns(10);
		txtAbstract.setBounds(24, 247, 631, 400);
		contentPane.add(txtAbstract);
		
		txtIssn = new JTextField();
		txtIssn.setToolTipText("");
		txtIssn.setHorizontalAlignment(SwingConstants.LEFT);
		txtIssn.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtIssn.setColumns(10);
		txtIssn.setBounds(299, 670, 223, 40);
		contentPane.add(txtIssn);
		
		//BUTTONS
		//btnUpload PDF
		JButton btnPdf = new JButton("upload pdf");
		btnPdf.setFont(new Font("Tahoma", Font.PLAIN, 17));
		btnPdf.setBounds(265, 740, 113, 74);
		contentPane.add(btnPdf);
		
		//btnSubmit
		JButton btnSubmit = new JButton("Submit");
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Testing
				
				User user = new User(); 
				int journalISSN = Integer.parseInt(txtIssn.getText());
				
				
					try {
						if (txtTitle.getText().equals("")) {
							JOptionPane.showMessageDialog(null, "Title field is empty", "Problem!", JOptionPane.INFORMATION_MESSAGE);}
						else if (txtAbstract.getText().contentEquals("")) {
							JOptionPane.showMessageDialog(null, "Abstract field is empty", "Problem!", JOptionPane.INFORMATION_MESSAGE);}
						else if (txtIssn.getText().contentEquals("")) {
							JOptionPane.showMessageDialog(null, "Journal Issn field is empty", "Problem!", JOptionPane.INFORMATION_MESSAGE);} 
						else if (user.checkJournalISSNExists(journalISSN) == false) {
							JOptionPane.showMessageDialog(null, "Journal Issn cannot be matched to an ISSN that already exists go back to Login and create a journal", "Problem!", JOptionPane.INFORMATION_MESSAGE);
						}else{
							
					
					
							try {
								
								String title = txtTitle.getText(); 
								String abstracts = txtAbstract.getText(); 
									
								String mainAuthor = LogInPage.currentUser;
										
								//user.update("Article", "Title", txtTitle.getText(), "MainAuthor", LogInPage.currentUser);
								//user.update("Article", "Abstracts",txtAbstract.getText(), "MainAuthor", LogInPage.currentUser);
										
										
								
								user.insertSubmissionData(journalISSN, title, abstracts, " ", " ", mainAuthor, "Pending", 0, 0, 0 ,"Pending" ,false );
								
								JOptionPane.showMessageDialog(null, "Article has been submitted!", "Done!", JOptionPane.INFORMATION_MESSAGE);
							}catch (ClassNotFoundException e1) {
						
								e1.printStackTrace();
							}catch (SQLException e1) {
								
								e1.printStackTrace();
							}
							
						}
					} catch (HeadlessException | SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
		

			}
		});
		btnSubmit.setFont(new Font("Tahoma", Font.PLAIN, 22));
		btnSubmit.setBounds(424, 738, 113, 74);
		contentPane.add(btnSubmit);
		
		//btnExit
		JButton btnExit = new JButton("exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnExit.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnExit.setBounds(24, 42, 81, 33);
		contentPane.add(btnExit);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBorder(new EmptyBorder(5, 5, 5, 5));
		panel.setBounds(712, 146, 682, 783);
		contentPane.add(panel);
		
		JLabel label_4 = new JLabel("Already registered user");
		label_4.setFont(new Font("Tahoma", Font.PLAIN, 23));
		label_4.setBounds(211, 41, 271, 51);
		panel.add(label_4);
		
		JLabel label_5 = new JLabel("Email  :");
		label_5.setFont(new Font("Tahoma", Font.PLAIN, 22));
		label_5.setBounds(158, 108, 91, 23);
		panel.add(label_5);
		
		JLabel label_6 = new JLabel("Title :");
		label_6.setFont(new Font("Tahoma", Font.PLAIN, 22));
		label_6.setBounds(218, 285, 72, 23);
		panel.add(label_6);
		
		JLabel label_7 = new JLabel("Forename : ");
		label_7.setFont(new Font("Tahoma", Font.PLAIN, 22));
		label_7.setBounds(161, 333, 127, 23);
		panel.add(label_7);
		
		JLabel label_8 = new JLabel("Surname : ");
		label_8.setFont(new Font("Tahoma", Font.PLAIN, 22));
		label_8.setBounds(171, 377, 117, 23);
		panel.add(label_8);
		
		JLabel label_9 = new JLabel("University affiliation : ");
		label_9.setFont(new Font("Tahoma", Font.PLAIN, 22));
		label_9.setBounds(66, 419, 226, 23);
		panel.add(label_9);
		
		JLabel label_10 = new JLabel("Email  :");
		label_10.setFont(new Font("Tahoma", Font.PLAIN, 22));
		label_10.setBounds(199, 465, 91, 23);
		panel.add(label_10);
		
		JLabel label_11 = new JLabel("Confirm Email  :");
		label_11.setFont(new Font("Tahoma", Font.PLAIN, 22));
		label_11.setBounds(116, 506, 167, 23);
		panel.add(label_11);
		
		JLabel label_12 = new JLabel("Password :");
		label_12.setFont(new Font("Tahoma", Font.PLAIN, 22));
		label_12.setBounds(165, 553, 119, 23);
		panel.add(label_12);
		
		JLabel label_13 = new JLabel("Confirm Password :");
		label_13.setFont(new Font("Tahoma", Font.PLAIN, 22));
		label_13.setBounds(82, 598, 189, 23);
		panel.add(label_13);
		
		JLabel label_14 = new JLabel("Non-registered user");
		label_14.setFont(new Font("Tahoma", Font.PLAIN, 23));
		label_14.setBounds(268, 232, 271, 51);
		panel.add(label_14);
		
		JLabel lblErrors = new JLabel("");
		lblErrors.setHorizontalAlignment(SwingConstants.CENTER);
		lblErrors.setForeground(Color.RED);
		lblErrors.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblErrors.setBounds(56, 202, 588, 31);
		panel.add(lblErrors);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Mr", "Mrs", "Dr", "Prof"}));
		comboBox.setMaximumRowCount(4);
		comboBox.setBounds(302, 285, 103, 31);
		panel.add(comboBox);
		
		
		//TEXTBOXES FOR ADDING AUTHORS TO BOARD
		txtEmailExist = new JTextField();
		txtEmailExist.setFont(new Font("Tahoma", Font.PLAIN, 21));
		txtEmailExist.setColumns(10);
		txtEmailExist.setBounds(244, 104, 271, 31);
		panel.add(txtEmailExist);
		
		txtForename = new JTextField();
		txtForename.setFont(new Font("Tahoma", Font.PLAIN, 21));
		txtForename.setColumns(10);
		txtForename.setBounds(300, 329, 178, 31);
		panel.add(txtForename);
		
		txtSurname = new JTextField();
		txtSurname.setFont(new Font("Tahoma", Font.PLAIN, 21));
		txtSurname.setColumns(10);
		txtSurname.setBounds(300, 373, 178, 31);
		panel.add(txtSurname);
		
		txtUni = new JTextField();
		txtUni.setFont(new Font("Tahoma", Font.PLAIN, 21));
		txtUni.setColumns(10);
		txtUni.setBounds(302, 417, 271, 31);
		panel.add(txtUni);
		
		txtEmail = new JTextField();
		txtEmail.setFont(new Font("Tahoma", Font.PLAIN, 21));
		txtEmail.setColumns(10);
		txtEmail.setBounds(302, 461, 271, 31);
		panel.add(txtEmail);
		
		txtConfEmail = new JTextField();
		txtConfEmail.setFont(new Font("Tahoma", Font.PLAIN, 21));
		txtConfEmail.setColumns(10);
		txtConfEmail.setBounds(302, 505, 271, 31);
		panel.add(txtConfEmail);
		
		//BUTTONS FOR ADDIGN AUTHOR TO BOARD
		
		//ADD button when user already exists
		JButton btnAddEmail = new JButton("ADD");
		btnAddEmail.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				x++;
				txtCounter.setText(Integer.toString(x));
				
				
				User k = new User();
				
				String loginID = txtEmailExist.getText();
				//String coAuthorName = k.getValue("User", "LoginID", loginID, "Forename");

				int submissionID;
				String coAuthorName; 
				String authorLoginID = txtEmailExist.getText();
				String authorLoginIDFromSignUP; 
				
				
				try {
					
					coAuthorName = k.getValueString("User", "LoginID",loginID , "Forename");
					
			
					submissionID = k.getValueInt("Submission", "MainAuthor", LogInPage.currentUser,  "SubmissionID" );
					
					if( k.checkEmailExists(loginID) == true ){
						
						k.insertCoAuthorsData(authorLoginID , submissionID, 0);
						
						User.update("User", "IsAuthor", 1, "LoginID ",authorLoginID );
						
						
						
					}else {
						lblErrors.setText("Email does not exits please sign up");
					}
					

				} catch (SQLException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
				
				
				
				
			}
		});
		btnAddEmail.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnAddEmail.setBounds(296, 159, 97, 31);
		panel.add(btnAddEmail);
		
		//ADD when you register the user now
		JButton btnAddNon = new JButton("ADD");
		btnAddNon.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				x++;
				txtCounter.setText(Integer.toString(x));
			}
		});
		btnAddNon.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnAddNon.setBounds(274, 739, 97, 31);
		panel.add(btnAddNon);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(302, 548, 271, 38);
		panel.add(passwordField);
		
		passwordConfirmField = new JPasswordField();
		passwordConfirmField.setBounds(302, 594, 271, 38);
		panel.add(passwordConfirmField);
		
		JButton btnAddAuthorNon = new JButton("ADD");
		btnAddAuthorNon.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			    User k = new User();
			    
				String title ;
				String value = comboBox.getSelectedItem().toString();
				
				if( value == "Mr") {
					title = "Mr";
				}else if(value ==  "Mrs") {
					title = "Mrs";
				}else if (value == "Dr") {
					title = "Dr";
				}else if (value=="Prof") {
					title = "Prof";
				}else{
					title = "none";
					lblErrors.setText("Please select your Title"); 
				}
				
				String forname = txtForename.getText();
				String surname = txtSurname.getText(); 
				String university = txtUni.getText();
				String email = txtEmail.getText(); 
				String confirmEmail = txtConfEmail.getText();
				String password = passwordField.getText();; 
				String confirmPassword = passwordConfirmField.getText();
				
				//System.out.println(title);
				//Set all to false to initialise
				boolean author = true; 
				boolean reviewer = false; 
				boolean editor = false; 
				

				//change the value of the user 
				if (LogInPage.register == true) {
					author = true; 
				}else if (LogInPage.register == false) {
					editor = true; 
				} 
				
				RegisterPage a = new RegisterPage();
				User newU = new User();
					
				//check all the fields have been completed
				//if all fields are not null then sign up user 
				if( a.isNull(forname) == true )   {
					lblErrors.setText("Please enter a valid Forname");
				}else if ( a.isNull(surname) == true  ) {
					lblErrors.setText("Please enter a valid Surname");
				}else if (a.isNull(university) == true ) {
					lblErrors.setText("Please enter a valid University");
				}else if  ( a.validateEmail(email)== false ) {
					lblErrors.setText("Please enter a valid Email");
				}else if (a.isNull(password) == true) {
					lblErrors.setText("Please enter a Password");
				}else if( a.isPasswordValid(password) == false) {
					lblErrors.setText( "Ensure your password has one UpperCase letter, 5-12 characters and 1 number" );
				}else if(a.isNull(confirmPassword)) {
					lblErrors.setText("Please confirm Password");
				}else if(email.equals(confirmEmail)==false) {
					lblErrors.setText("Please make sure both emails match");
				}else if(password.equals(confirmPassword)==false) {
					lblErrors.setText( "Please make sure both passowords match" );
				} else
					try {
						if(newU.checkEmailExists(email) == true) {
							lblErrors.setText( "This email is already in use" );
						}
					} catch (SQLException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
						
						
				//This is the final check the login page will have to pass
				//if all the fields in the login are not null and satisfy the above 
				//then the user will be allowed to sign up as a user
				
				try {
					if( (a.isNull(forname) == false  && a.isNull(surname) ==false   && a.isNull(university) == false  && a.validateEmail(email)== true && a.isNull(password) == false
							&& a.isPasswordValid(password) == true && (a.isNull(confirmEmail)== false && email.equals(confirmEmail)==true) && password.equals(confirmPassword)==true) && newU.checkEmailExists(email) == false
							){
						lblErrors.setForeground(Color.black);
						lblErrors.setText("Thank You For Signing Up User");
					}
				} catch (SQLException e2) {
				
					e2.printStackTrace();
				}
				

				//execute the query and add data into the data base over here
				//meaning everything check out and user can finally be registered
				
				if(lblErrors.getText().equals("Thank You For Signing Up User")) {
					//create a user
					User pushData = new User(); 
					
					
					
					try {
						
						//push data into DB
						pushData.insertUserData(title, forname, surname, university, email, confirmPassword.hashCode(), reviewer, editor, author);
						
						int submissionID = k.getValueInt("Submission", "MainAuthor", LogInPage.currentUser,  "SubmissionID" );
						
						//int articleID = k.getValueInt("Artcle", conditionParam, matchingVariable, colName)
						
						k.insertCoAuthorsData( email , submissionID , 0);
						
						
						
					} catch (ClassNotFoundException | SQLException e1) {
						e1.printStackTrace();
					}
							
					x++;
					txtCounter.setText(Integer.toString(x));;
					dispose();
				
				}	
			
			}
		});
		btnAddAuthorNon.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnAddAuthorNon.setBounds(335, 647, 97, 31);
		panel.add(btnAddAuthorNon);
		
		//LABELS FOR ADDING AUTHOR TO BOARD
		JLabel label_2 = new JLabel("Add Author to the Board");
		label_2.setBounds(906, 86, 284, 51);
		contentPane.add(label_2);
		label_2.setFont(new Font("Tahoma", Font.PLAIN, 25));
		
		
	}
}